class AccountNotFoundException extends Error {}

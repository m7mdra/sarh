class InvalidDataException extends Error {}

const HTTP_UNAUTHORIZED = 401;

class SessionExpiredException extends Error {}

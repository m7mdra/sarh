class UnableToConnectException extends Error {}

class LoadClientEvent {}

class LoadClients extends LoadClientEvent {}

class RetryLoad extends LoadClientEvent {}

class AddCompanyInfoEvent {}

class LoadCompanySize extends AddCompanyInfoEvent {}

class AuthorizerEvent{}
class LoadAuthroizers extends AuthorizerEvent{}
class CompanyProfileEvent {}

class LoadProfile extends CompanyProfileEvent {}

class RefreshProfile extends CompanyProfileEvent {}

class GalleryEvent {}

class LoadGalleries extends GalleryEvent {}

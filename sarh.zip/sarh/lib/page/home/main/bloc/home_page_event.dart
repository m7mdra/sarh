class HomePageEvent {}

class NavigateToProfile extends HomePageEvent {}

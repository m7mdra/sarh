class HomePageState {}

class NavigateToCompanyProfile extends HomePageState {}

class NavigateToUserProfile extends HomePageState {}

class HomePageIdle extends HomePageState {}

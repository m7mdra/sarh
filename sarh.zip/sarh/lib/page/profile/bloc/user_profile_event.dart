class UserProfileEvent {}

class LoadProfile extends UserProfileEvent {}

class RefreshProfile extends UserProfileEvent {}

class QuotesEvent {}

class LoadQuotes extends QuotesEvent {}

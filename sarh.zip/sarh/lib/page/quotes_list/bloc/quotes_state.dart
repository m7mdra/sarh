class QuoteState {}

class Loading extends QuoteState {}

class Success extends QuoteState {}

class NetworkError extends QuoteState {}

class Error extends QuoteState {}

class SessionExpired extends QuoteState {}

class Timeout extends QuoteState {}

class Empty extends QuoteState {}

class SessionEvent {}

class AppStarted extends SessionEvent {}

class Update extends SessionEvent {}
